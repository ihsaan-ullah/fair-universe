# ------------------------------
# Dummy Sample Submission
# ------------------------------
class Model:
    """
    This is a model class to be submitted by the participants in their submission.

    This class should consists of the following functions
    1) init : initialize a classifier
    2) fit : can be used to train a classifier
    3) predict: predict mu_hats and delta_mu_hat

    Note:   Add more methods if needed e.g. save model, load pre-trained model etc.
            It is the participant's responsibility to make sure that the submission 
            class is named "Model" and that its constructor arguments remains the same.
            The ingestion program initializes the Model class and calls fit and predict methods
    """

    def __init__(
            self,
            train_set=None,
            systematics=None
    ):
        """
        Model class constructor

        Params:
            data_gen:
                data generator

            test_sets:
                unlabelled test sets

            SEED:
                random seed

        Returns:
            None
        """

    def fit(self):
        """
        Params:
            None

        Functionality:
            this function can be used to generate multiple datasets and train a model
            or anything else to do with the data generator

        Returns:
            None
        """
        pass

    def predict(self):
        """
        Params:
            None

        Functionality:
            this function can be used for predictions using the test sets

        Returns:
            dict with keys
                - mu_hats (list of predicted mus - one for each test set)
                - delta_mu_hat (one value)
        """

        return {
            "mu_hat": 1,
            "delta_mu_hat": 0.1,
            "p16": 1.0,
            "p84": 1.0
        }
