# Getting Stated

### Starting Kit
Starting Kit provides an overview of the problem, how to load data and train a model using the data and to make predictions using the test data, compute score, make submissions to be uploaded on Codabench.

Download [**starting kit**](https://www.codabench.org/datasets/download/60cabbc4-6d58-44ae-a2a7-420ace2c3823/)

### Public Data
Once you get familiar with the starting kit and want to use a bigger dataset, public data is what you are looking for.

Download [**Public Data**](https://www.codabench.org/datasets/download/814aa909-c8f2-4308-b119-ea2cb2f49d99/)


### Sample Submissions
Sample submissions are for test purposes, you can submit either code submission or result submission to test what score do you get.

Download [**sample code submisison**](https://www.codabench.org/datasets/download/fd3b2ca0-8475-4166-8922-627abb5f3dc8/)  

Download [**sample result submisison**](https://www.codabench.org/datasets/download/4b8e5a8c-b442-400f-806e-f480c30a2144/)
